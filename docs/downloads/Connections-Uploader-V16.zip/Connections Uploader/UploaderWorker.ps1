﻿param(
  [Parameter(Mandatory=$true)][string]$JobPath
)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Net.Http
Add-Type -AssemblyName System.Security

$ApiKey = 'AIzaSyCOcLbVFoTcqE1y67wN4J19xHsJX7J7iok'
$ProjectId = 'cnx-cf-20260930'
$WorkerBase = 'https://cnx-gh-media.pixlcyd.workers.dev'
$AppDir = Join-Path $env:LOCALAPPDATA 'ConnectionsUploader-gh'
$TokenPath = Join-Path $AppDir 'auth.json'
$job = Get-Content -LiteralPath $JobPath -Raw | ConvertFrom-Json
$statusPath = [string]$job.statusPath
$cancelPath = [string]$job.cancelPath
$source = [string]$job.sourcePath
$keepConverted = [bool]$job.keepConverted
$createdOutput = $false
$session = $null
$client = [System.Net.Http.HttpClient]::new()
$client.Timeout = [TimeSpan]::FromHours(12)

function Write-Status([string]$state,[double]$progress,[string]$detail,[hashtable]$extra=@{}) {
  $data = @{ state=$state; progress=[Math]::Max(0,[Math]::Min(100,[Math]::Round($progress,1))); detail=$detail; updatedAt=[DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds() }
  foreach($key in $extra.Keys){$data[$key]=$extra[$key]}
  $tmp = "$statusPath.tmp"
  $data | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $tmp -Encoding UTF8
  Move-Item -LiteralPath $tmp -Destination $statusPath -Force
}
function Throw-IfCancelled { if(Test-Path -LiteralPath $cancelPath){ throw [System.OperationCanceledException]::new('Cancelled') } }
function Find-Exe([string]$name){
  $cmd=Get-Command $name -ErrorAction SilentlyContinue
  if($cmd){return $cmd.Source}
  $roots=@(
    "$env:LOCALAPPDATA\Microsoft\WinGet\Links\$name.exe",
    "$env:ProgramFiles\ffmpeg\bin\$name.exe",
    "$env:ProgramFiles\Gyan\ffmpeg\bin\$name.exe",
    "$env:ChocolateyInstall\bin\$name.exe"
  )
  foreach($candidate in $roots){if($candidate -and (Test-Path -LiteralPath $candidate)){return $candidate}}
  return $null
}
function Unprotect-Text([string]$value){
  $bytes=[Convert]::FromBase64String($value)
  $plain=[System.Security.Cryptography.ProtectedData]::Unprotect($bytes,$null,[System.Security.Cryptography.DataProtectionScope]::CurrentUser)
  return [System.Text.Encoding]::UTF8.GetString($plain)
}
function Get-Auth {
  if(!(Test-Path -LiteralPath $TokenPath)){throw 'Sign in from Connections Uploader first.'}
  $saved=Get-Content -LiteralPath $TokenPath -Raw | ConvertFrom-Json
  $refresh=Unprotect-Text ([string]$saved.refreshToken)
  $body="grant_type=refresh_token&refresh_token=$([Uri]::EscapeDataString($refresh))"
  $response=Invoke-RestMethod -Method Post -Uri "https://securetoken.googleapis.com/v1/token?key=$ApiKey" -ContentType 'application/x-www-form-urlencoded' -Body $body
  return @{ idToken=[string]$response.id_token; refreshToken=[string]$response.refresh_token; uid=[string]$response.user_id; handle=[string]$saved.handle; issued=[DateTime]::UtcNow }
}
$auth=$null
function Ensure-Auth {
  if($null -eq $auth -or (([DateTime]::UtcNow-$auth.issued).TotalMinutes -gt 45)){$script:auth=Get-Auth}
  return $auth
}
function Read-JsonResponse($response){
  $text=$response.Content.ReadAsStringAsync().GetAwaiter().GetResult()
  if(!$response.IsSuccessStatusCode){
    try{
      $parsed=$text|ConvertFrom-Json
      if($parsed.error -is [string]){$message=[string]$parsed.error}
      elseif($parsed.error.message){$message=[string]$parsed.error.message}else{$message=$text}
    }catch{$message=$text}
    if([string]::IsNullOrWhiteSpace($message)){$message="Request failed ($([int]$response.StatusCode))"}
    if(([int]$response.StatusCode -eq 403) -and $message -match 'permission'){throw 'Connections Firestore rules are out of date. Deploy Connections V12, then press Retry. Your uploaded video can be retried after the rules update.'}
    throw $message
  }
  if([string]::IsNullOrWhiteSpace($text)){return $null}
  return $text|ConvertFrom-Json
}
function Send-Json([string]$method,[string]$uri,$payload,[bool]$authenticated=$true){
  Throw-IfCancelled
  $request=[System.Net.Http.HttpRequestMessage]::new([System.Net.Http.HttpMethod]::new($method),$uri)
  if($authenticated){$a=Ensure-Auth;$request.Headers.Authorization=[System.Net.Http.Headers.AuthenticationHeaderValue]::new('Bearer',$a.idToken)}
  if($null -ne $payload){$json=$payload|ConvertTo-Json -Depth 20 -Compress;$request.Content=[System.Net.Http.StringContent]::new($json,[System.Text.Encoding]::UTF8,'application/json')}
  try{$response=$client.SendAsync($request).GetAwaiter().GetResult();return Read-JsonResponse $response}finally{$request.Dispose()}
}
function Clean-Title([string]$text){
  $value=$text -replace '[._]+',' '
  $value=$value -replace '\b(2160p|1080p|720p|4k|uhd|bluray|blu-ray|web[ ._-]?dl|webrip|hdr|dv|dovi|x264|x265|h264|h265|hevc|av1|aac|eac3|ac3|ddp|dts).*$', ''
  return ($value -replace '\s+',' ').Trim(' ','-','.')
}
function Parse-Name([string]$path){
  $raw=[System.IO.Path]::GetFileNameWithoutExtension($path)
  $m=[regex]::Match($raw,'^(.*?)[._ -]+[Ss](\d{1,2})[Ee](\d{1,3})[._ -]*(.*)$')
  if($m.Success){$show=Clean-Title $m.Groups[1].Value;$show=($show -replace '\s*\(?((?:19|20)\d{2})\)?\s*$','').Trim();return @{kind='tv';lookup=$show;showTitle=$show;season=[int]$m.Groups[2].Value;episode=[int]$m.Groups[3].Value;episodeTitle=(Clean-Title $m.Groups[4].Value);year=''}}
  $yearMatch=[regex]::Match($raw,'(?:^|\W)((?:19|20)\d{2})(?:\W|$)')
  $year=if($yearMatch.Success){$yearMatch.Groups[1].Value}else{''}
  $prefix=if($yearMatch.Success){$raw.Substring(0,$yearMatch.Index)}else{$raw}
  $title=Clean-Title $prefix
  return @{kind='movie';lookup=$title;title=$title;showTitle='';season=0;episode=0;episodeTitle='';year=$year}
}
function Get-Metadata($details){
  $result=@{id=0;title=$details.lookup;year=$details.year;description='';poster='';backdrop='';episodeTitle=$details.episodeTitle;episodeDescription='';episodeStill=''}
  if([string]::IsNullOrWhiteSpace($details.lookup)){return $result}
  try{
    $q=[Uri]::EscapeDataString($details.lookup)
    $type=if($details.kind -eq 'tv'){'tv'}else{'movie'}
    $search=Invoke-RestMethod -Method Get -Uri "$WorkerBase/api/movie-discover?tab=match&type=$type&q=$q" -TimeoutSec 12
    $item=$search.items | Where-Object {$_.title -and $_.title.ToLowerInvariant() -eq $details.lookup.ToLowerInvariant()} | Select-Object -First 1
    if(!$item){$item=$search.items|Select-Object -First 1}
    if($item){
      $result.id=[int]$item.id;$result.title=[string]$item.title;$result.year=[string]$item.year;$result.description=[string]$item.description;$result.poster=[string]$item.poster;$result.backdrop=[string]$item.backdrop
      if($details.kind -eq 'tv' -and $details.episode -gt 0){
        try{$season=Invoke-RestMethod -Method Get -Uri "$WorkerBase/api/tv-season?id=$($result.id)&season=$($details.season)" -TimeoutSec 12;$ep=$season.episodes|Where-Object {[int]$_.number -eq [int]$details.episode}|Select-Object -First 1;if($ep){$result.episodeTitle=[string]$ep.title;$result.episodeDescription=[string]$ep.description;$result.episodeStill=[string]$ep.still}}catch{}
      }
    }
  }catch{}
  return $result
}
function Invoke-Probe([string]$ffprobe,[string]$path){
  $json=& $ffprobe -v quiet -print_format json -show_format -show_streams $path | Out-String
  if(!$json.Trim()){throw 'FFprobe could not read this file.'}
  return $json|ConvertFrom-Json
}
function Run-FFmpeg([string]$ffmpeg,[string[]]$arguments,[double]$duration,[string]$stage,[double]$from,[double]$to){
  Throw-IfCancelled
  $psi=[System.Diagnostics.ProcessStartInfo]::new();$psi.FileName=$ffmpeg;$psi.UseShellExecute=$false;$psi.CreateNoWindow=$true;$psi.RedirectStandardOutput=$true;$psi.RedirectStandardError=$true
  $psi.Arguments=($arguments | ForEach-Object { if($_ -match '[\s\"]'){ '"' + ([string]$_).Replace('\"','\\\"') + '"' } else { [string]$_ } }) -join ' '
  $process=[System.Diagnostics.Process]::new();$process.StartInfo=$psi
  if(!$process.Start()){throw 'Could not start FFmpeg.'}
  $stderrTask=$process.StandardError.ReadToEndAsync()
  try{
    while(!$process.StandardOutput.EndOfStream){
      $line=$process.StandardOutput.ReadLine();Throw-IfCancelled
      if($line -like 'out_time_ms=*' -and $duration -gt 0){$micros=[double]($line.Substring(12));$ratio=[Math]::Max(0,[Math]::Min(1,($micros/1000000)/$duration));Write-Status $stage ($from+(($to-$from)*$ratio)) "$stage | $([Math]::Round($ratio*100))%"}
    }
    $err=$stderrTask.GetAwaiter().GetResult();$process.WaitForExit()
    if($process.ExitCode -ne 0){$message=if($err.Trim()){$err.Trim()}else{"FFmpeg failed with code $($process.ExitCode)."};throw $message}
  }catch{
    try{if(!$process.HasExited){$process.Kill()}}catch{}
    throw
  }finally{$process.Dispose()}
}
function Upload-File([string]$path,[string]$contentType,[double]$from,[double]$to){
  $file=[System.IO.FileInfo]::new($path);if($file.Length -le 0){throw 'Output file is empty.'}
  $a=Ensure-Auth
  $start=Send-Json 'POST' "$WorkerBase/media/start" @{name=$file.Name;type=$contentType;size=[long]$file.Length}
  $script:session=$start
  $partSize=[int64]$start.partSize;$parts=New-Object System.Collections.ArrayList
  $stream=[System.IO.File]::Open($path,[System.IO.FileMode]::Open,[System.IO.FileAccess]::Read,[System.IO.FileShare]::Read)
  try{
    $part=1;$uploaded=[int64]0
    while($uploaded -lt $file.Length){
      Throw-IfCancelled
      $want=[int][Math]::Min($partSize,$file.Length-$uploaded);$buffer=New-Object byte[] $want;$read=0
      while($read -lt $want){$n=$stream.Read($buffer,$read,$want-$read);if($n -le 0){break};$read+=$n}
      if($read -ne $want){throw 'Unexpected end of file while uploading.'}
      $a=Ensure-Auth
      $uri="$WorkerBase/media/part?key=$([Uri]::EscapeDataString([string]$start.key))&uploadId=$([Uri]::EscapeDataString([string]$start.uploadId))&part=$part"
      $result=$null;$lastError=$null
      for($attempt=1;$attempt -le 4;$attempt++){
        Throw-IfCancelled;$request=[System.Net.Http.HttpRequestMessage]::new([System.Net.Http.HttpMethod]::Put,$uri);$request.Headers.Authorization=[System.Net.Http.Headers.AuthenticationHeaderValue]::new('Bearer',$a.idToken);$request.Content=[System.Net.Http.ByteArrayContent]::new($buffer)
        try{$response=$client.SendAsync($request).GetAwaiter().GetResult();$result=Read-JsonResponse $response;$lastError=$null;break}catch{$lastError=$_.Exception.Message;if($attempt -lt 4){Write-Status 'Uploading' ($from+(($to-$from)*($uploaded/[double]$file.Length))) "Upload hiccup | retry $attempt/3...";Start-Sleep -Seconds ([Math]::Min(6,$attempt*2))}}finally{$request.Dispose()}
      }
      if($lastError){throw "Upload part $part failed after retries: $lastError"}
      [void]$parts.Add(@{partNumber=[int]$result.partNumber;etag=[string]$result.etag});$uploaded+=$read;$part++
      $ratio=$uploaded/[double]$file.Length;Write-Status 'Uploading' ($from+(($to-$from)*$ratio)) "Uploading | $([Math]::Round($ratio*100))% | $([Math]::Round($uploaded/1GB,1)) / $([Math]::Round($file.Length/1GB,1)) GB"
    }
  }finally{$stream.Dispose()}
  $complete=Send-Json 'POST' "$WorkerBase/media/complete" @{key=[string]$start.key;uploadId=[string]$start.uploadId;parts=@($parts)}
  $script:session=$null
  return [string]$complete.url
}
function Upload-Small([string]$path,[string]$contentType){
  $a=Ensure-Auth;$bytes=[System.IO.File]::ReadAllBytes($path);$request=[System.Net.Http.HttpRequestMessage]::new([System.Net.Http.HttpMethod]::Post,"$WorkerBase/media/upload");$request.Headers.Authorization=[System.Net.Http.Headers.AuthenticationHeaderValue]::new('Bearer',$a.idToken);$request.Headers.Add('X-File-Type',$contentType);$request.Headers.Add('X-File-Name',[Uri]::EscapeDataString([System.IO.Path]::GetFileName($path)));$request.Content=[System.Net.Http.ByteArrayContent]::new($bytes)
  try{$response=$client.SendAsync($request).GetAwaiter().GetResult();$result=Read-JsonResponse $response;return [string]$result.url}finally{$request.Dispose()}
}
function Firestore-String([string]$value){return @{stringValue=$value}}
function Firestore-Int([long]$value){return @{integerValue=[string]$value}}
function Register-Movie([string]$docId,[string]$url,[long]$size,$details,$meta){
  $a=Ensure-Auth;$docName="projects/$ProjectId/databases/(default)/documents/apps/gh/movies/$docId"
  $isTv=$details.kind -eq 'tv'
  $title=if($isTv){if($meta.title){$meta.title}else{$details.showTitle}}else{if($meta.title){$meta.title}else{$details.title}}
  $showTitle=if($isTv){$title}else{''}
  $description=if($isTv -and $meta.episodeDescription){$meta.episodeDescription}else{$meta.description}
  $backdrop=if($isTv -and $meta.episodeStill){$meta.episodeStill}else{$meta.backdrop}
  $episodeTitle=if($isTv){if($meta.episodeTitle){$meta.episodeTitle}else{$details.episodeTitle}}else{''}
  $fields=@{
    ownerUid=Firestore-String $a.uid;url=Firestore-String $url;title=Firestore-String ([string]$title).Substring(0,[Math]::Min(120,([string]$title).Length));kind=Firestore-String ([string]$details.kind);showTitle=Firestore-String ([string]$showTitle).Substring(0,[Math]::Min(120,([string]$showTitle).Length));season=Firestore-Int ([long]$details.season);episode=Firestore-Int ([long]$details.episode);episodeTitle=Firestore-String ([string]$episodeTitle).Substring(0,[Math]::Min(120,([string]$episodeTitle).Length));year=Firestore-String ([string]$meta.year).Substring(0,[Math]::Min(4,([string]$meta.year).Length));description=Firestore-String ([string]$description).Substring(0,[Math]::Min(800,([string]$description).Length));poster=Firestore-String ([string]$meta.poster).Substring(0,[Math]::Min(400,([string]$meta.poster).Length));backdrop=Firestore-String ([string]$backdrop).Substring(0,[Math]::Min(400,([string]$backdrop).Length));captionUrl=Firestore-String '';size=Firestore-Int $size;tmdbId=Firestore-Int ([long]$meta.id)
  }
  $payload=@{writes=@(@{update=@{name=$docName;fields=$fields};updateTransforms=@(@{fieldPath='createdAt';setToServerValue='REQUEST_TIME'});currentDocument=@{exists=$false}})}
  [void](Send-Json 'POST' "https://firestore.googleapis.com/v1/projects/$ProjectId/databases/(default)/documents:commit" $payload)
}
function Update-Caption([string]$docId,[string]$captionUrl){
  $docName="projects/$ProjectId/databases/(default)/documents/apps/gh/movies/$docId";$payload=@{writes=@(@{update=@{name=$docName;fields=@{captionUrl=Firestore-String $captionUrl}};updateMask=@{fieldPaths=@('captionUrl')}})}
  [void](Send-Json 'POST' "https://firestore.googleapis.com/v1/projects/$ProjectId/databases/(default)/documents:commit" $payload)
}
function Abort-Upload {
  if($null -ne $session){try{[void](Send-Json 'POST' "$WorkerBase/media/abort" @{key=[string]$session.key;uploadId=[string]$session.uploadId})}catch{};$script:session=$null}
}

$output=$null;$caption=$null
try{
  if(!(Test-Path -LiteralPath $source -PathType Leaf)){throw 'The selected file no longer exists.'}
  Write-Status 'Preparing' 1 'Checking FFmpeg and your Connections account...'
  $ffmpeg=Find-Exe 'ffmpeg';$ffprobe=Find-Exe 'ffprobe';if(!$ffmpeg -or !$ffprobe){throw 'FFmpeg was not found. In Connections Uploader, click Install FFmpeg, then retry.'}
  $auth=Get-Auth;Throw-IfCancelled
  Write-Status 'Probing' 3 'Inspecting video, audio, subtitles and metadata...'
  $probe=Invoke-Probe $ffprobe $source;$duration=[double]$probe.format.duration
  $video=$probe.streams|Where-Object {$_.codec_type -eq 'video' -and !$_.disposition.attached_pic}|Select-Object -First 1
  $audio=$probe.streams|Where-Object {$_.codec_type -eq 'audio' -and $_.tags.language -in @('eng','en')}|Select-Object -First 1
  if(!$audio){$audio=$probe.streams|Where-Object {$_.codec_type -eq 'audio'}|Select-Object -First 1}
  if(!$video -and !$audio){throw 'No playable video or audio stream was found.'}
  if(!$video){
    $tags=$probe.format.tags
    $title=if($tags.title){[string]$tags.title}else{[IO.Path]::GetFileNameWithoutExtension($source)}
    $artist=if($tags.artist){[string]$tags.artist}else{''}
    $album=if($tags.album){[string]$tags.album}else{''}
    $details=@{kind='song';title=$title;lookup=$title;year='';showTitle='';season=0;episode=0;episodeTitle=''}
    $meta=@{id=0;title=$title;year='';description=(@($artist,$album)|Where-Object {$_}) -join ' | ';poster='';backdrop=''}
    $ready=$source
    if([IO.Path]::GetExtension($source).ToLowerInvariant() -notin @('.mp3','.m4a','.wav','.ogg')){
      $output=Join-Path ([IO.Path]::GetDirectoryName($source)) ([IO.Path]::GetFileNameWithoutExtension($source)+'.connections.'+[Guid]::NewGuid().ToString('N').Substring(0,8)+'.m4a')
      Run-FFmpeg $ffmpeg @('-y','-hide_banner','-loglevel','error','-i',$source,'-map',('0:'+[string]$audio.index),'-vn','-c:a','aac','-b:a','192k','-movflags','+faststart','-progress','pipe:1','-nostats',$output) $duration 'Preparing song' 7 35
      $ready=$output
    }
    $contentType=switch([IO.Path]::GetExtension($ready).ToLowerInvariant()){'.mp3'{'audio/mpeg'}'.wav'{'audio/wav'}'.ogg'{'audio/ogg'}default{'audio/mp4'}}
    $size=(Get-Item -LiteralPath $ready).Length;Write-Status 'Song detected' 36 ($title+' | Uploading audio to R2...')
    $mediaUrl=Upload-File $ready $contentType 36 94
    Register-Movie ([Guid]::NewGuid().ToString()) $mediaUrl $size $details $meta
    Write-Status 'Complete' 100 ($title+' is now in the Music tab.') @{url=$mediaUrl;outputPath=$ready}
    exit 0
  }
  $details=Parse-Name $source;$meta=Get-Metadata $details
  $pretty=if($details.kind -eq 'tv'){"$($meta.title) | S$('{0:D2}' -f [int]$details.season)E$('{0:D2}' -f [int]$details.episode)$(if($meta.episodeTitle){' | '+$meta.episodeTitle})"}else{"$($meta.title)$(if($meta.year){' ('+$meta.year+')'})"}
  Write-Status 'Detected' 5 $pretty @{metadata=$pretty}
  Throw-IfCancelled
  $sourceExt=[System.IO.Path]::GetExtension($source).ToLowerInvariant();$videoCodec=[string]$video.codec_name;$pixelFormat=[string]$video.pix_fmt;$audioCodec=if($audio){[string]$audio.codec_name}else{''};$webH264=($videoCodec -eq 'h264' -and $pixelFormat -in @('yuv420p','yuvj420p','nv12'))
  $direct=($sourceExt -eq '.mp4' -and $webH264 -and (!$audio -or $audioCodec -eq 'aac'))
  $dir=[System.IO.Path]::GetDirectoryName($source);$base=[System.IO.Path]::GetFileNameWithoutExtension($source);$output=Join-Path $dir ($base+'.connections.mp4')
  $reusable=$false
  if(!$direct -and (Test-Path -LiteralPath $output)){try{$existing=Invoke-Probe $ffprobe $output;$ev=$existing.streams|Where-Object {$_.codec_type -eq 'video'}|Select-Object -First 1;$ea=$existing.streams|Where-Object {$_.codec_type -eq 'audio'}|Select-Object -First 1;$reusable=($ev.codec_name -eq 'h264' -and (!$ea -or $ea.codec_name -eq 'aac') -and [Math]::Abs([double]$existing.format.duration-$duration) -lt 3 -and (Get-Item -LiteralPath $output).LastWriteTimeUtc -ge (Get-Item -LiteralPath $source).LastWriteTimeUtc)}catch{}}
  if($reusable){$ready=$output;Write-Status 'Ready' 55 'Reusing completed MP4 conversion - no conversion wait.'}
  elseif($direct){$ready=$source;Write-Status 'Ready' 28 'Already H.264 + AAC MP4 - no quality-losing conversion needed.'}
  else{
    $createdOutput=$true;if(Test-Path -LiteralPath $output){$output=Join-Path $dir ($base+'.connections.'+[Guid]::NewGuid().ToString('N').Substring(0,8)+'.mp4')}
    $nvenc=(((& $ffmpeg -hide_banner -encoders 2>&1 | Out-String) -match 'h264_nvenc'))
    $ffArgs=[System.Collections.Generic.List[string]]::new();@('-y','-hide_banner','-loglevel','error','-i',$source,'-map','0:v:0','-map',$(if($audio){'0:'+[string]$audio.index}else{'0:a:0?'}))|ForEach-Object{$ffArgs.Add($_)}
    if($webH264){@('-c:v','copy')|ForEach-Object{$ffArgs.Add($_)};$stage='Remuxing'}else{
      if($nvenc){@('-c:v','h264_nvenc','-preset','p4','-tune','hq','-rc','vbr','-cq','23','-b:v','4M','-maxrate','6M','-bufsize','12M','-spatial_aq','1','-temporal_aq','1','-profile:v','high','-pix_fmt','yuv420p')|ForEach-Object{$ffArgs.Add($_)};$stage='Converting on NVIDIA GPU'}else{@('-c:v','libx264','-preset','fast','-crf','23','-profile:v','high','-pix_fmt','yuv420p')|ForEach-Object{$ffArgs.Add($_)};$stage='Converting on CPU'}
    }
    if($audio){if($audioCodec -eq 'aac'){@('-c:a','copy')|ForEach-Object{$ffArgs.Add($_)}}else{@('-c:a','aac','-b:a','192k')|ForEach-Object{$ffArgs.Add($_)}}}
    @('-movflags','+faststart','-progress','pipe:1','-nostats',$output)|ForEach-Object{$ffArgs.Add($_)}
    Run-FFmpeg $ffmpeg $ffArgs.ToArray() $duration $stage 7 55;$ready=$output
  }
  Throw-IfCancelled
  $sub=$probe.streams|Where-Object {$_.codec_type -eq 'subtitle' -and $_.codec_name -in @('subrip','ass','ssa','webvtt') -and ($_.tags.language -in @('eng','en') -or !$_.tags.language)}|Select-Object -First 1
  if(!$sub){$sub=$probe.streams|Where-Object {$_.codec_type -eq 'subtitle' -and $_.codec_name -in @('subrip','ass','ssa','webvtt')}|Select-Object -First 1}
  if($sub){$caption=Join-Path $dir ($base+'.connections.en.vtt');try{if(Test-Path $caption){Remove-Item $caption -Force};& $ffmpeg -y -hide_banner -loglevel error -i $source -map "0:$($sub.index)" -c:s webvtt $caption;if($LASTEXITCODE -ne 0){$caption=$null}}catch{$caption=$null}}
  $readyInfo=[System.IO.FileInfo]::new($ready);if($readyInfo.Length -gt 100GB){throw 'The converted file is over the current 100 GB Connections limit.'}
  Write-Status 'Uploading' 56 "Uploading $([Math]::Round($readyInfo.Length/1GB,1)) GB to Connections..." @{metadata=$pretty}
  $mediaUrl=Upload-File $ready 'video/mp4' 56 94
  Throw-IfCancelled
  $docId=[Guid]::NewGuid().ToString();Write-Status 'Adding to library' 95 'Adding this title to the Connections library...' @{metadata=$pretty}
  Register-Movie $docId $mediaUrl ([long]$readyInfo.Length) $details $meta
  if($caption -and (Test-Path $caption)){Write-Status 'Captions' 97 'Uploading English captions...' @{metadata=$pretty};$captionUrl=Upload-Small $caption 'text/vtt';Update-Caption $docId $captionUrl}
  Write-Status 'Complete' 100 "$pretty is now available in Connections." @{metadata=$pretty;url=$mediaUrl;outputPath=$ready}
  if($createdOutput -and !$keepConverted -and $output -and (Test-Path $output)){Remove-Item -LiteralPath $output -Force}
  if($caption -and !$keepConverted -and (Test-Path $caption)){Remove-Item -LiteralPath $caption -Force}
  exit 0
}catch [System.OperationCanceledException]{
  Abort-Upload;Write-Status 'Cancelled' 0 'Cancelled.';exit 2
}catch{
  Abort-Upload;$message=$_.Exception.Message;if($message.Length -gt 900){$message=$message.Substring(0,900)};Write-Status 'Failed' 0 $message @{error=$message};exit 1
}finally{$client.Dispose()}
