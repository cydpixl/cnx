﻿CONNECTIONS UPLOADER - V12

1. Double-click START_CONNECTIONS_UPLOADER.cmd.
2. Sign in with the same username/password you use on Connections.
3. Drop MKV/MP4/MOV/M2TS/etc. files into the window.
4. The app detects the codec and title automatically.
5. Compatible H.264/AAC MP4 files upload directly. H.264 in another container is remuxed without quality loss. HEVC/x265/other video is converted to high-quality H.264 MP4 using NVIDIA NVENC when available.
6. After upload, the movie/episode appears in Connections automatically.

TV filenames work best with normal SxxExx naming, for example:
  Ted.S01E04.1080p.BluRay.x265.mkv

The uploader uses Connections' own Firebase account authentication. Passwords are never saved. A Firebase refresh token is stored encrypted with Windows DPAPI for your Windows user.

FFmpeg:
- If FFmpeg is already in PATH, nothing else is needed.
- If it is missing, click "Install FFmpeg with winget" inside the uploader.

Large files:
- Connections V12 supports multipart uploads up to 100 GB per title.
- Uploads are sent in 64 MiB resumable R2 parts.
- Converted output can be kept or automatically removed after a successful upload.

V12 fixes:
- 100 GB multipart path is the only size path; no legacy 4 GB gate.
- Clear Firestore rules error when an older deployment blocks library registration.
- Windows PowerShell encoding fixed so arrows/dashes do not turn into mojibake.
