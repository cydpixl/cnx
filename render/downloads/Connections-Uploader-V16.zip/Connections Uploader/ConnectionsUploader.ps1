﻿$ErrorActionPreference='Stop'
Add-Type -AssemblyName PresentationFramework,PresentationCore,WindowsBase,System.Xaml,System.Security
Add-Type -AssemblyName System.Net.Http

$ScriptDir=Split-Path -Parent $MyInvocation.MyCommand.Path
$WorkerScript=Join-Path $ScriptDir 'UploaderWorker.ps1'
$IconPath=Join-Path $ScriptDir 'assets\connections.ico'
$AppDir=Join-Path $env:LOCALAPPDATA 'ConnectionsUploader-rd'
$JobsDir=Join-Path $AppDir 'jobs'
$TokenPath=Join-Path $AppDir 'auth.json'
$ApiKey='AIzaSyCOcLbVFoTcqE1y67wN4J19xHsJX7J7iok'
New-Item -ItemType Directory -Force -Path $AppDir,$JobsDir|Out-Null

[xml]$xaml=@'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation" xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml" Title="Connections Uploader" Width="1040" Height="720" MinWidth="860" MinHeight="600" WindowStartupLocation="CenterScreen" Background="#0B0C0F" Foreground="#F4F4F5" FontFamily="Segoe UI" WindowStyle="None" ResizeMode="CanResize" AllowsTransparency="False" Opacity="0">
  <Window.Resources>
    <SolidColorBrush x:Key="Panel" Color="#121318"/><SolidColorBrush x:Key="Panel2" Color="#181A20"/><SolidColorBrush x:Key="Border" Color="#292C35"/><SolidColorBrush x:Key="Muted" Color="#9498A6"/><SolidColorBrush x:Key="Accent" Color="#5865F2"/>
    <Style TargetType="Button"><Setter Property="Foreground" Value="#F6F6F7"/><Setter Property="Background" Value="#20222A"/><Setter Property="BorderBrush" Value="#343741"/><Setter Property="BorderThickness" Value="1"/><Setter Property="Padding" Value="13,8"/><Setter Property="FontWeight" Value="SemiBold"/><Setter Property="Cursor" Value="Hand"/><Setter Property="Template"><Setter.Value><ControlTemplate TargetType="Button"><Border x:Name="b" Background="{TemplateBinding Background}" BorderBrush="{TemplateBinding BorderBrush}" BorderThickness="{TemplateBinding BorderThickness}" CornerRadius="8"><ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/></Border><ControlTemplate.Triggers><Trigger Property="IsMouseOver" Value="True"><Setter TargetName="b" Property="Background" Value="#2A2D36"/></Trigger><Trigger Property="IsPressed" Value="True"><Setter TargetName="b" Property="Opacity" Value=".75"/></Trigger><Trigger Property="IsEnabled" Value="False"><Setter TargetName="b" Property="Opacity" Value=".4"/></Trigger></ControlTemplate.Triggers></ControlTemplate></Setter.Value></Setter></Style>
    <Style TargetType="TextBox"><Setter Property="Foreground" Value="#F5F5F6"/><Setter Property="Background" Value="#0E0F13"/><Setter Property="BorderBrush" Value="#323540"/><Setter Property="BorderThickness" Value="1"/><Setter Property="Padding" Value="11,9"/><Setter Property="CaretBrush" Value="#FFFFFF"/><Setter Property="FontSize" Value="13"/></Style>
    <Style TargetType="PasswordBox"><Setter Property="Foreground" Value="#F5F5F6"/><Setter Property="Background" Value="#0E0F13"/><Setter Property="BorderBrush" Value="#323540"/><Setter Property="BorderThickness" Value="1"/><Setter Property="Padding" Value="11,9"/><Setter Property="CaretBrush" Value="#FFFFFF"/><Setter Property="FontSize" Value="13"/></Style>
    <Style TargetType="ProgressBar"><Setter Property="Height" Value="5"/><Setter Property="Background" Value="#22242B"/><Setter Property="Foreground" Value="#6975FF"/><Setter Property="BorderThickness" Value="0"/></Style>
  </Window.Resources>
  <Border BorderBrush="#252831" BorderThickness="1" Background="#0B0C0F">
    <Grid>
      <Grid.RowDefinitions><RowDefinition Height="48"/><RowDefinition Height="*"/><RowDefinition Height="38"/></Grid.RowDefinitions>
      <Border x:Name="TitleBar" Grid.Row="0" Background="#101116" BorderBrush="#242730" BorderThickness="0,0,0,1">
        <Grid Margin="16,0,8,0"><Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions>
          <StackPanel Orientation="Horizontal" VerticalAlignment="Center"><Image x:Name="TopIcon" Width="22" Height="22" Margin="0,0,9,0"/><TextBlock Text="Connections Uploader" FontWeight="Bold" FontSize="13" VerticalAlignment="Center"/><Border Margin="10,0,0,0" Padding="7,3" CornerRadius="8" Background="#171923"><TextBlock Text="V12" Foreground="#9298FF" FontSize="9" FontWeight="Bold"/></Border></StackPanel>
          <StackPanel Grid.Column="1" Orientation="Horizontal"><Button x:Name="MinButton" Content="-" Width="38" Height="30" Padding="0" Margin="2,0" Background="Transparent" BorderBrush="Transparent"/><Button x:Name="CloseButton" Content="X" Width="38" Height="30" Padding="0" Margin="2,0" Background="Transparent" BorderBrush="Transparent" FontSize="18"/></StackPanel>
        </Grid>
      </Border>
      <ScrollViewer Grid.Row="1" VerticalScrollBarVisibility="Auto"><Grid Margin="24,22,24,24"><Grid.ColumnDefinitions><ColumnDefinition Width="330"/><ColumnDefinition Width="22"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions>
        <StackPanel Grid.Column="0">
          <TextBlock Text="Drop it. Done." FontSize="31" FontWeight="Bold"/><TextBlock Text="Connections converts only when it needs to, keeps quality high, then uploads directly into your movie library." Foreground="#9A9EAA" TextWrapping="Wrap" Margin="0,6,0,18" FontSize="12" LineHeight="18"/>
          <Border Background="#121318" BorderBrush="#292C35" BorderThickness="1" CornerRadius="13" Padding="15" Margin="0,0,0,13">
            <StackPanel><Grid><Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions><StackPanel><TextBlock Text="Connections account" FontWeight="Bold" FontSize="12"/><TextBlock x:Name="AuthHint" Text="Sign in with your Connections username." Foreground="#8D919D" FontSize="10" Margin="0,3,0,0"/></StackPanel><Border x:Name="SignedPill" Grid.Column="1" Background="#16231C" CornerRadius="9" Padding="8,4" Visibility="Collapsed"><TextBlock x:Name="SignedText" Text="Connected" Foreground="#71D393" FontSize="9" FontWeight="Bold"/></Border></Grid>
              <StackPanel x:Name="LoginPanel" Margin="0,13,0,0"><TextBox x:Name="UsernameBox" Margin="0,0,0,8" ToolTip="Connections username"/><PasswordBox x:Name="PasswordBox" Margin="0,0,0,9" ToolTip="Connections password"/><Button x:Name="SignInButton" Content="Sign in to Connections" Background="#5865F2" BorderBrush="#5865F2"/></StackPanel>
              <StackPanel x:Name="SignedActions" Orientation="Horizontal" Margin="0,11,0,0" Visibility="Collapsed"><Button x:Name="SignOutButton" Content="Sign out" Padding="10,6" FontSize="10"/><TextBlock Text="Your password is never saved." Foreground="#6F7380" FontSize="9" VerticalAlignment="Center" Margin="10,0,0,0"/></StackPanel>
            </StackPanel>
          </Border>
          <Border Background="#121318" BorderBrush="#292C35" BorderThickness="1" CornerRadius="13" Padding="15" Margin="0,0,0,13"><StackPanel><TextBlock Text="Conversion" FontWeight="Bold" FontSize="12"/><TextBlock x:Name="FfmpegStatus" Text="Checking FFmpeg..." Foreground="#8D919D" FontSize="10" Margin="0,4,0,10"/><CheckBox x:Name="KeepConverted" Content="Keep converted MP4 beside the original" Foreground="#C7C9D0" FontSize="10" Margin="0,0,0,10"/><Button x:Name="InstallFfmpeg" Content="Install FFmpeg with winget" Padding="10,7" FontSize="10"/></StackPanel></Border>
          <Border Background="#101116" BorderBrush="#252831" BorderThickness="1" CornerRadius="13" Padding="15"><StackPanel><TextBlock Text="Smart conversion" FontWeight="Bold" FontSize="11"/><TextBlock Text="H.264 + AAC MP4 -> uploads directly&#10;H.264 MKV -> remuxes without quality loss&#10;HEVC / x265 -> RTX NVENC H.264 CQ 18&#10;Text subtitles -> WebVTT captions" Foreground="#858996" FontSize="10" LineHeight="17" Margin="0,7,0,0"/></StackPanel></Border>
        </StackPanel>
        <StackPanel Grid.Column="2">
          <Border x:Name="DropBorder" Height="190" CornerRadius="16" Background="#111217" BorderBrush="#343844" BorderThickness="1" AllowDrop="True" RenderTransformOrigin=".5,.5"><Border.RenderTransform><ScaleTransform x:Name="DropScale" ScaleX="1" ScaleY="1"/></Border.RenderTransform><Grid><Rectangle Stroke="#454A58" StrokeThickness="1" StrokeDashArray="5 4" RadiusX="14" RadiusY="14" Margin="8"/><StackPanel HorizontalAlignment="Center" VerticalAlignment="Center"><Border Width="52" Height="52" CornerRadius="16" Background="#1C1E27"><TextBlock Text="v" FontSize="28" HorizontalAlignment="Center" VerticalAlignment="Center" Foreground="#9EA4FF"/></Border><TextBlock Text="Drop movies or TV episodes here" FontWeight="Bold" FontSize="15" HorizontalAlignment="Center" Margin="0,12,0,4"/><TextBlock Text="MKV | MP4 | MOV | M2TS | AVI | WebM | up to 100 GB" Foreground="#878B98" FontSize="10" HorizontalAlignment="Center"/><Button x:Name="ChooseButton" Content="Choose files" Margin="0,13,0,0" Padding="16,7"/></StackPanel></Grid></Border>
          <Grid Margin="0,19,0,9"><Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions><StackPanel><TextBlock Text="Queue" FontWeight="Bold" FontSize="15"/><TextBlock x:Name="QueueSub" Text="Nothing queued" Foreground="#7F838F" FontSize="10" Margin="0,2,0,0"/></StackPanel><Button x:Name="ClearButton" Grid.Column="1" Content="Clear finished" FontSize="10" Padding="10,6"/></Grid>
          <Border Background="#101116" BorderBrush="#252831" BorderThickness="1" CornerRadius="13" MinHeight="270"><Grid><TextBlock x:Name="EmptyQueue" Text="Your converted uploads will appear here." Foreground="#676B78" HorizontalAlignment="Center" VerticalAlignment="Center" FontSize="11"/><StackPanel x:Name="QueuePanel" Margin="10"/></Grid></Border>
        </StackPanel>
      </Grid></ScrollViewer>
      <Border Grid.Row="2" Background="#0E0F13" BorderBrush="#22252D" BorderThickness="0,1,0,0"><Grid Margin="16,0"><Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions><TextBlock x:Name="FooterStatus" Text="Ready" Foreground="#777B88" FontSize="9" VerticalAlignment="Center"/><TextBlock Grid.Column="1" Text="Connections | direct R2 upload | resumable multipart" Foreground="#555965" FontSize="9" VerticalAlignment="Center"/></Grid></Border>
    </Grid>
  </Border>
</Window>
'@
$reader=New-Object System.Xml.XmlNodeReader $xaml
$window=[System.Windows.Markup.XamlReader]::Load($reader)
function C($name){$window.FindName($name)}
$TitleBar=C 'TitleBar';$MinButton=C 'MinButton';$CloseButton=C 'CloseButton';$TopIcon=C 'TopIcon';$AuthHint=C 'AuthHint';$SignedPill=C 'SignedPill';$SignedText=C 'SignedText';$LoginPanel=C 'LoginPanel';$SignedActions=C 'SignedActions';$UsernameBox=C 'UsernameBox';$PasswordBox=C 'PasswordBox';$SignInButton=C 'SignInButton';$SignOutButton=C 'SignOutButton';$FfmpegStatus=C 'FfmpegStatus';$InstallFfmpeg=C 'InstallFfmpeg';$KeepConverted=C 'KeepConverted';$DropBorder=C 'DropBorder';$DropScale=C 'DropScale';$ChooseButton=C 'ChooseButton';$QueuePanel=C 'QueuePanel';$EmptyQueue=C 'EmptyQueue';$QueueSub=C 'QueueSub';$ClearButton=C 'ClearButton';$FooterStatus=C 'FooterStatus'
if(Test-Path $IconPath){$window.Icon=[System.Windows.Media.Imaging.BitmapFrame]::Create([Uri]$IconPath);$TopIcon.Source=$window.Icon}
$jobs=New-Object System.Collections.ArrayList
$active=$null
$signedIn=$false

function Protect-Text([string]$value){$bytes=[System.Text.Encoding]::UTF8.GetBytes($value);return [Convert]::ToBase64String([System.Security.Cryptography.ProtectedData]::Protect($bytes,$null,[System.Security.Cryptography.DataProtectionScope]::CurrentUser))}
function Unprotect-Text([string]$value){$bytes=[Convert]::FromBase64String($value);$plain=[System.Security.Cryptography.ProtectedData]::Unprotect($bytes,$null,[System.Security.Cryptography.DataProtectionScope]::CurrentUser);return [System.Text.Encoding]::UTF8.GetString($plain)}
function Set-AuthUi([bool]$ok,[string]$handle=''){$script:signedIn=$ok;$LoginPanel.Visibility=if($ok){'Collapsed'}else{'Visible'};$SignedActions.Visibility=if($ok){'Visible'}else{'Collapsed'};$SignedPill.Visibility=if($ok){'Visible'}else{'Collapsed'};if($ok){$SignedText.Text="@$handle connected";$AuthHint.Text='Uploads will appear in this account.';$FooterStatus.Text="Signed in as @$handle"}else{$AuthHint.Text='Sign in with your Connections username.';$FooterStatus.Text='Sign in to upload'}}
function Test-SavedAuth {
  if(!(Test-Path $TokenPath)){return $false}
  try{$saved=Get-Content $TokenPath -Raw|ConvertFrom-Json;$refresh=Unprotect-Text ([string]$saved.refreshToken);$body="grant_type=refresh_token&refresh_token=$([Uri]::EscapeDataString($refresh))";$null=Invoke-RestMethod -Method Post -Uri "https://securetoken.googleapis.com/v1/token?key=$ApiKey" -ContentType 'application/x-www-form-urlencoded' -Body $body -TimeoutSec 12;Set-AuthUi $true ([string]$saved.handle);return $true}catch{Remove-Item $TokenPath -Force -ErrorAction SilentlyContinue;return $false}
}
function Refresh-ProcessPath {
  $machine=[Environment]::GetEnvironmentVariable('Path','Machine');$user=[Environment]::GetEnvironmentVariable('Path','User');$env:Path="$machine;$user"
}
function Find-LocalExe([string]$name){
  Refresh-ProcessPath;$cmd=Get-Command $name -ErrorAction SilentlyContinue;if($cmd){return $cmd.Source}
  $candidates=@("$env:LOCALAPPDATA\Microsoft\WinGet\Links\$name.exe","$env:ProgramFiles\ffmpeg\bin\$name.exe","$env:ProgramFiles\Gyan\ffmpeg\bin\$name.exe","$env:ChocolateyInstall\bin\$name.exe")
  foreach($candidate in $candidates){if($candidate -and (Test-Path -LiteralPath $candidate)){return $candidate}}
  return $null
}
function Update-FfmpegStatus {$ff=Find-LocalExe 'ffmpeg';$fp=Find-LocalExe 'ffprobe';if($ff -and $fp){$FfmpegStatus.Text='FFmpeg detected | smart conversion ready';$FfmpegStatus.Foreground='#73D49A';$InstallFfmpeg.Content='Recheck FFmpeg'}else{$FfmpegStatus.Text='FFmpeg not detected yet';$FfmpegStatus.Foreground='#E7B566';$InstallFfmpeg.Content='Install FFmpeg with winget'}}
function New-Text([string]$text,[string]$color='#F4F4F5',[double]$size=11,[string]$weight='Normal'){$t=[System.Windows.Controls.TextBlock]::new();$t.Text=$text;$t.Foreground=$color;$t.FontSize=$size;$t.FontWeight=$weight;$t.TextTrimming='CharacterEllipsis';return $t}
function Add-Job([string]$path){
  if(!(Test-Path -LiteralPath $path -PathType Leaf)){return};$ext=[System.IO.Path]::GetExtension($path).ToLowerInvariant();if($ext -notin @('.mkv','.mp4','.mov','.m4v','.avi','.webm','.m2ts','.mts','.ts')){$FooterStatus.Text="Skipped unsupported file: $([System.IO.Path]::GetFileName($path))";return}
  $id=[Guid]::NewGuid().ToString();$statusPath=Join-Path $JobsDir "$id.status.json";$manifestPath=Join-Path $JobsDir "$id.job.json";$cancelPath=Join-Path $JobsDir "$id.cancel"
  $card=[System.Windows.Controls.Border]::new();$card.Background='#17181D';$card.BorderBrush='#2C2F38';$card.BorderThickness='1';$card.CornerRadius='10';$card.Padding='12';$card.Margin='0,0,0,8'
  $grid=[System.Windows.Controls.Grid]::new();$grid.RowDefinitions.Add([System.Windows.Controls.RowDefinition]::new());$grid.RowDefinitions.Add([System.Windows.Controls.RowDefinition]::new());$grid.RowDefinitions.Add([System.Windows.Controls.RowDefinition]::new());$grid.ColumnDefinitions.Add([System.Windows.Controls.ColumnDefinition]::new());$auto=[System.Windows.Controls.ColumnDefinition]::new();$auto.Width='Auto';$grid.ColumnDefinitions.Add($auto)
  $name=New-Text ([System.IO.Path]::GetFileName($path)) '#F3F4F6' 11 'Bold';[System.Windows.Controls.Grid]::SetRow($name,0);$grid.Children.Add($name)|Out-Null
  $action=[System.Windows.Controls.Button]::new();$action.Content='Cancel';$action.Tag=$id;$action.Padding='9,5';$action.FontSize=9;$action.Margin='9,0,0,0';[System.Windows.Controls.Grid]::SetColumn($action,1);[System.Windows.Controls.Grid]::SetRow($action,0);$grid.Children.Add($action)|Out-Null
  $meta=New-Text 'Queued | waiting for account' '#7F8390' 9;[System.Windows.Controls.Grid]::SetRow($meta,1);[System.Windows.Controls.Grid]::SetColumnSpan($meta,2);$meta.Margin='0,4,0,8';$grid.Children.Add($meta)|Out-Null
  $progress=[System.Windows.Controls.ProgressBar]::new();$progress.Minimum=0;$progress.Maximum=100;$progress.Value=0;[System.Windows.Controls.Grid]::SetRow($progress,2);[System.Windows.Controls.Grid]::SetColumnSpan($progress,2);$grid.Children.Add($progress)|Out-Null
  $card.Child=$grid;$QueuePanel.Children.Add($card)|Out-Null
  $job=[pscustomobject]@{id=$id;path=$path;statusPath=$statusPath;manifestPath=$manifestPath;cancelPath=$cancelPath;card=$card;meta=$meta;progress=$progress;action=$action;state='Queued';process=$null}
  [void]$jobs.Add($job);$EmptyQueue.Visibility='Collapsed';$action.Add_Click({param($sender,$e);$j=$jobs|Where-Object id -eq ([string]$sender.Tag)|Select-Object -First 1;if(!$j){return};if($j.state -eq 'Failed' -or $j.state -eq 'Cancelled'){$j.state='Queued';$j.meta.Text='Queued | retrying';$j.progress.Value=0;Remove-Item $j.cancelPath,$j.statusPath -Force -ErrorAction SilentlyContinue;$sender.Content='Cancel';Start-Next}else{New-Item -ItemType File -Force -Path $j.cancelPath|Out-Null;$j.meta.Text='Cancelling...';$sender.IsEnabled=$false}})
  Update-QueueSummary;Start-Next
}
function Update-QueueSummary {$pending=@($jobs|Where-Object {$_.state -notin @('Complete','Cancelled')}).Count;$QueueSub.Text=if($jobs.Count -eq 0){'Nothing queued'}elseif($pending -eq 0){"$($jobs.Count) finished"}else{"$pending remaining | $($jobs.Count) total"}}
function Start-Next {
  if($script:active -or !$signedIn){return};$job=$jobs|Where-Object state -eq 'Queued'|Select-Object -First 1;if(!$job){Update-QueueSummary;return}
  $manifest=@{id=$job.id;sourcePath=$job.path;statusPath=$job.statusPath;cancelPath=$job.cancelPath;keepConverted=[bool]$KeepConverted.IsChecked};$manifest|ConvertTo-Json -Depth 5|Set-Content -LiteralPath $job.manifestPath -Encoding UTF8
  Remove-Item $job.statusPath,$job.cancelPath -Force -ErrorAction SilentlyContinue;$psi=[System.Diagnostics.ProcessStartInfo]::new();$psi.FileName='powershell.exe';$escapedWorker=$WorkerScript.Replace('"','\"');$escapedJob=$job.manifestPath.Replace('"','\"');$psi.Arguments="-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$escapedWorker`" -JobPath `"$escapedJob`"";$psi.UseShellExecute=$false;$psi.CreateNoWindow=$true;$job.process=[System.Diagnostics.Process]::Start($psi);$job.state='Starting';$job.meta.Text='Starting...';$job.action.IsEnabled=$true;$script:active=$job;$FooterStatus.Text="Processing $([System.IO.Path]::GetFileName($job.path))";Update-QueueSummary
}
function Add-Files([string[]]$paths){foreach($path in $paths){Add-Job $path}}

$poll=[System.Windows.Threading.DispatcherTimer]::new();$poll.Interval=[TimeSpan]::FromMilliseconds(350);$poll.Add_Tick({
  if(!$script:active){Start-Next;return};$job=$script:active
  if(Test-Path -LiteralPath $job.statusPath){try{$status=Get-Content -LiteralPath $job.statusPath -Raw|ConvertFrom-Json;$job.state=[string]$status.state;$job.progress.Value=[double]$status.progress;$job.meta.Text=[string]$status.detail;if($job.state -eq 'Complete'){$job.progress.Value=100;$job.progress.Foreground='#67D18F';$job.action.Visibility='Collapsed';$FooterStatus.Text=[string]$status.detail;$script:active=$null;Update-QueueSummary;Start-Next}elseif($job.state -eq 'Failed'){$job.progress.Foreground='#E06C75';$job.action.Content='Retry';$job.action.IsEnabled=$true;$FooterStatus.Text="Failed | $($status.detail)";$script:active=$null;Update-QueueSummary;Start-Next}elseif($job.state -eq 'Cancelled'){$job.action.Content='Retry';$job.action.IsEnabled=$true;$FooterStatus.Text='Cancelled';$script:active=$null;Update-QueueSummary;Start-Next}}catch{}}
  if($job.process -and $job.process.HasExited -and $script:active -eq $job -and $job.state -notin @('Complete','Failed','Cancelled')){$job.state='Failed';$job.meta.Text='Uploader worker stopped unexpectedly. Press Retry.';$job.action.Content='Retry';$job.action.IsEnabled=$true;$script:active=$null;Start-Next}
})
$poll.Start()

$SignInButton.Add_Click({
  $handle=$UsernameBox.Text.Trim().ToLowerInvariant();$password=$PasswordBox.Password;if($handle -notmatch '^[a-z0-9_]{3,20}$'){$AuthHint.Text='Use your 3-20 character Connections username.';return};if($password.Length -lt 8){$AuthHint.Text='Password must be at least 8 characters.';return};$SignInButton.IsEnabled=$false;$SignInButton.Content='Signing in...'
  try{$email="$handle@users.connections.invalid";$payload=@{email=$email;password=$password;returnSecureToken=$true}|ConvertTo-Json -Compress;$response=Invoke-RestMethod -Method Post -Uri "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=$ApiKey" -ContentType 'application/json' -Body $payload -TimeoutSec 15;$saved=@{handle=$handle;refreshToken=Protect-Text ([string]$response.refreshToken)};$saved|ConvertTo-Json|Set-Content -LiteralPath $TokenPath -Encoding UTF8;$PasswordBox.Clear();Set-AuthUi $true $handle;Start-Next}catch{$AuthHint.Text='Could not sign in. Check your username and password.'}finally{$SignInButton.IsEnabled=$true;$SignInButton.Content='Sign in to Connections'}
})
$SignOutButton.Add_Click({Remove-Item $TokenPath -Force -ErrorAction SilentlyContinue;Set-AuthUi $false;$UsernameBox.Clear();$PasswordBox.Clear()})
$InstallFfmpeg.Add_Click({if((Find-LocalExe 'ffmpeg') -and (Find-LocalExe 'ffprobe')){Update-FfmpegStatus;return};$winget=Get-Command winget -ErrorAction SilentlyContinue;if(!$winget){$FooterStatus.Text='Winget is unavailable. Install FFmpeg manually, then click Recheck.';return};Start-Process $winget.Source -ArgumentList 'install --id Gyan.FFmpeg -e --accept-package-agreements --accept-source-agreements';$FooterStatus.Text='FFmpeg installer opened. When it finishes, click Recheck FFmpeg.'})
$ChooseButton.Add_Click({$dialog=[Microsoft.Win32.OpenFileDialog]::new();$dialog.Multiselect=$true;$dialog.Filter='Videos and songs|*.mkv;*.mp4;*.mov;*.m4v;*.avi;*.webm;*.m2ts;*.mts;*.ts;*.mp3;*.m4a;*.flac;*.wav;*.ogg;*.opus;*.aac|All files|*.*';if($dialog.ShowDialog()) {Add-Files $dialog.FileNames}})
$DropBorder.Add_DragEnter({$_.Effects='Copy';$DropBorder.Background='#171925';$DropBorder.BorderBrush='#6975FF';$anim=[System.Windows.Media.Animation.DoubleAnimation]::new(1,1.012,[TimeSpan]::FromMilliseconds(120));$DropScale.BeginAnimation([System.Windows.Media.ScaleTransform]::ScaleXProperty,$anim);$DropScale.BeginAnimation([System.Windows.Media.ScaleTransform]::ScaleYProperty,$anim)})
$DropBorder.Add_DragLeave({$DropBorder.Background='#111217';$DropBorder.BorderBrush='#343844';$DropScale.ScaleX=1;$DropScale.ScaleY=1})
$DropBorder.Add_Drop({$DropBorder.Background='#111217';$DropBorder.BorderBrush='#343844';$DropScale.ScaleX=1;$DropScale.ScaleY=1;if($_.Data.GetDataPresent([System.Windows.DataFormats]::FileDrop)){Add-Files ([string[]]$_.Data.GetData([System.Windows.DataFormats]::FileDrop))}})
$ClearButton.Add_Click({foreach($j in @($jobs|Where-Object {$_.state -in @('Complete','Cancelled')})){[void]$QueuePanel.Children.Remove($j.card);[void]$jobs.Remove($j);Remove-Item $j.statusPath,$j.manifestPath,$j.cancelPath -Force -ErrorAction SilentlyContinue};if($jobs.Count -eq 0){$EmptyQueue.Visibility='Visible'};Update-QueueSummary})
$TitleBar.Add_MouseLeftButtonDown({if($_.ChangedButton -eq 'Left'){$window.DragMove()}});$MinButton.Add_Click({$window.WindowState='Minimized'});$CloseButton.Add_Click({$window.Close()})
$window.Add_Loaded({$window.Opacity=1;try{$fade=[System.Windows.Media.Animation.DoubleAnimation]::new(0,1,[TimeSpan]::FromMilliseconds(240));$window.BeginAnimation([System.Windows.Window]::OpacityProperty,$fade)}catch{};try{Update-FfmpegStatus;if(!(Test-SavedAuth)){Set-AuthUi $false}}catch{$FooterStatus.Text='Startup check failed: '+$_.Exception.Message;Set-AuthUi $false}})
$window.Add_Closed({$poll.Stop()})
[void]$window.ShowDialog()
